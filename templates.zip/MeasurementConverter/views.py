from django.shortcuts import render

# Conversion factors relative to meters
conversion_factors = {
    'feet': 0.3048,
    'cm': 0.01,
    'inches': 0.0254,
    'meters': 1.0,
    'miles': 1609.34,
}

def converter(request):
    result = None

    if request.method == 'POST':
        try:
            distance = float(request.POST['distance'])
            from_unit = request.POST['from_unit']
            to_unit = request.POST['to_unit']
            meters = distance * conversion_factors[from_unit]
            result = meters / conversion_factors[to_unit]
            result = round(result, 4)
        except Exception:
            result = "Invalid input"

    return render(request, 'index.html', {
        'result': result,
        'units': conversion_factors.keys()
    })
